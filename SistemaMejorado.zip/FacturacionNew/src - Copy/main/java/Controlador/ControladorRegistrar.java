/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controlador;

import Modelo.Usuario;
import Modelo.UsuarioDali;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


public class ControladorRegistrar extends HttpServlet {

    private static final String EMAIL_REGEX = "^[a-z0-9]+(?:\\.[a-z0-9]+)*@(?:[a-z]+\\.)+[a-z]{2,7}$";

    private boolean validarEmail(String email) {
        return email.matches(EMAIL_REGEX);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accion = request.getParameter("btnRegistrar");
        System.out.println("Hola" + accion);
        if (accion.equals("Registrar")) {
            String correo = request.getParameter("correo");
            String contra = request.getParameter("contra");
            if (!validarEmail(correo)) {
                System.out.println("Validación");
                request.setAttribute("error", "Formato de correo electrónico inválido.");
                request.getRequestDispatcher("registrate.jsp").forward(request, response);
                return;
            }


            UsuarioDali usuarioDali = new UsuarioDali();
            int resultado = usuarioDali.registrar(correo, contra);

            if (resultado > 0) {
                response.sendRedirect("index.jsp");
            } else {
                request.setAttribute("error", "Error al registrar el usuario.");
                request.getRequestDispatcher("error.jsp").forward(request, response);
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}