/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controlador;

import Modelo.Articulo;
import Modelo.CabeceraDali;
import Modelo.CabeceraFactura;
import Modelo.Cliente;
import Modelo.ClientesDali;
import Modelo.Usuario;
import Modelo.UsuarioDali;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import Modelo.DetalleFactura;
import Modelo.Empleado;
import Modelo.EmpleadosDali;
/**
 *
 * @author saman /controlador
 */
public class Controlador extends HttpServlet {
    int res;
    Usuario us = new Usuario();
   
    Articulo articulos= new Articulo();
    DetalleFactura dFac = new DetalleFactura();
    List<DetalleFactura> lista = new ArrayList();
    String descripcion;
    double precioUnitario=0.0;
    int cantidad;
    double precioTotal;
    double TotalFac=0.0;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
             UsuarioDali val = new UsuarioDali();
		response.setContentType("text/html; charset=UTF-8");
		String accion = request.getParameter("accion");
                if (accion.equals("Ingresar")) {
                    String correo = request.getParameter("txtcorreo");
                    String contra = request.getParameter("txtcontra");
                    us.setCorreo(correo);
                    us.setContrasena(contra);
                    res = val.validar(us);
                    if (res == 1) {
                            request.getSession().setAttribute("correo", correo);
                            request.getSession().setAttribute("contra", contra);
                            HttpSession session = request.getSession();
                        List<Articulo> listaArticulos = val.listarArticulos(us);
                     // Después de obtener la lista de artículos
                        List<String> descripciones = new ArrayList<>();
                        List<Double> precios = new ArrayList<>();
                        for (Articulo articulo : listaArticulos) {
                            descripciones.add(articulo.getDescripcion());
                            precios.add(articulo.getPrecio_u());
                        }
                      
                        session.setAttribute("usuario", us);
                        session.setAttribute("descripciones", descripciones);
                        session.setAttribute("precios", precios);
                        
                        response.sendRedirect(request.getContextPath() + "/menu.jsp");

                    } else {
                       request.getRequestDispatcher("index.jsp").forward(request, response);
                    }
                }
                if(accion.equals("BuscarPrecio")){
                    HttpSession session = request.getSession();
                    session.setAttribute("usuario", us);
                    System.out.println("Buscar");
                    String des = request.getParameter("descripcion");
                    articulos = val.buscarArticuloPorDescripcion(us, des);
                    request.setAttribute("articulo", articulos);
                    request.setAttribute("totalpag", TotalFac);
                    request.setAttribute("lista", lista);
                    request.getRequestDispatcher("/menu.jsp").forward(request, response);
                }
                if(accion.equals("Agregar")){
                    System.out.println("Agregandooo");
                    TotalFac =0.0;
                    descripcion = request.getParameter("desProducto");
                    System.out.println(descripcion);
                    cantidad = Integer.parseInt(request.getParameter("cantidad"));
                     System.out.println(cantidad);
                      System.out.println(request.getParameter("punit"));
                    if ((request.getParameter("punit")) != null) {
                         precioUnitario = Double.parseDouble(request.getParameter("punit"));
                    }
                    precioTotal = precioUnitario*cantidad;
                    
                    boolean encontrado = false;
                    for (DetalleFactura detalle : lista) {
                        if (detalle.getDescripcion().equals(descripcion)) {
                            // El producto ya existe, actualizar cantidad y precio total
                            detalle.setCantidad(detalle.getCantidad() + cantidad);
                            detalle.setPrecioTotal(detalle.getPrecioTotal() + precioTotal);
                            encontrado = true;
                            break;
                        }
                    }
                    if (!encontrado) {
                    dFac = new DetalleFactura();
                    dFac.setCantidad(cantidad);
                    dFac.setDescripcion(descripcion);
                    dFac.setPrecioTotal(precioTotal);
                    dFac.setPrecioUnitario(precioUnitario);
                    System.out.println("Cantidad: " + dFac.getCantidad());
                    System.out.println("Descripción: " + dFac.getDescripcion());
                    System.out.println("Precio Total: " + dFac.getPrecioTotal());
                    System.out.println("Precio Unitario: " + dFac.getPrecioUnitario());
                    lista.add(dFac);
                    }
                    for (int i = 0; i < lista.size(); i++) {
                        TotalFac = TotalFac + lista.get(i).getPrecioTotal();
                    }
                    request.setAttribute("totalpag", TotalFac);
                    request.setAttribute("lista", lista);
                    
                    request.getRequestDispatcher("/menu.jsp").forward(request, response);
                }
                if (accion.equals("Eliminar")) {
                    String descripcionEliminar = request.getParameter("descripcionEliminar");
                    for (int i = 0; i < lista.size(); i++) {
                        DetalleFactura detalle = lista.get(i);
                        if (detalle.getDescripcion().equals(descripcionEliminar)) {
                            lista.remove(i);
                            break;
                        }
                    }
                    double TotalFac = 0.0;
                    for (DetalleFactura detalle : lista) {
                        TotalFac += detalle.getPrecioTotal();
                    }
                    request.setAttribute("totalpag", TotalFac);
                    request.setAttribute("lista", lista);
                    request.getRequestDispatcher("/menu.jsp").forward(request, response);
                }/*
                if(accion.equals("Refrescar Factura")) {
                    HttpSession session = request.getSession();
                    List<Articulo> listaArticulos = val.listarArticulos(us);
                    List<Double> precios = new ArrayList<>();
                    List<String> descripciones = new ArrayList<>();
                    for (Articulo articulo : listaArticulos) {
                        System.out.println("ARTICULO: "+articulo.getDescripcion());
                        descripciones.add(articulo.getDescripcion());
                        precios.add(articulo.getPrecio_u());
                    }
                    session.setAttribute("usuario", us);
                    session.setAttribute("descripciones", descripciones);
                    session.setAttribute("precios", precios);
                    request.getRequestDispatcher("/menu.jsp").forward(request, response);
                }*/
                if(accion.equals("GuardarFactura")){
                    System.out.println("enviando fac");
                    HttpSession session = request.getSession();
                    Usuario usuario = (Usuario) session.getAttribute("usuario");
                    String fecha = request.getParameter("inputFechae");
                    String rucClienteStr = request.getParameter("inputRuce");
                    String codigoVendedor = request.getParameter("inputNroe");
                    double TotalFac = Double.parseDouble(request.getParameter("TotalFactura"));
                    double igv = Double.parseDouble(request.getParameter("IGV"));
                    double SubTotal = Double.parseDouble(request.getParameter("SubTotalFactura"));
                    CabeceraFactura cabeceraFactura = new CabeceraFactura();
                    cabeceraFactura.setFecha(fecha);
                    cabeceraFactura.setRuc_cliente(rucClienteStr);
                    cabeceraFactura.setCodigo_vendedor(codigoVendedor);
                    cabeceraFactura.setTotal_fact(TotalFac);
                    cabeceraFactura.setIgv(igv);
                    cabeceraFactura.setSub_total(SubTotal);

                    CabeceraDali cabeceraDali = new CabeceraDali();
                    ClientesDali clienteval = new ClientesDali();
                    EmpleadosDali empleadoval = new EmpleadosDali();
                    
                    Cliente valc = clienteval.buscarClientePorRucYCorreo(rucClienteStr, usuario);
                    Empleado vale = empleadoval.buscarEmpleadoPorDniYCorreo(codigoVendedor, usuario);
                    
                    if(valc!=null){
                        if(vale!=null){
                            int res = cabeceraDali.guardar(cabeceraFactura, usuario);
                            if (res > 0) {
                                System.out.println("Correo"+usuario.getCorreo());
                                
                                lista =new ArrayList<>();
                                TotalFac = 0.0;
                                
                                response.setContentType("text/html");
                                try (PrintWriter out = response.getWriter()) {
                                    out.println("<script type=\"text/javascript\">");
                                    out.println("alert('Se guardo la factura');");
                                    out.println("location='menu.jsp';");
                                    out.println("</script>");
                                }
                                response.sendRedirect("menu.jsp");
                            } else {
                                    request.getRequestDispatcher("error.jsp").forward(request, response);
                            }
                        }
                        else{
                            response.setContentType("text/html");
                            try (PrintWriter out = response.getWriter()) {
                                out.println("<script type=\"text/javascript\">");
                                out.println("alert('No se encontro el empleado');");
                                out.println("location='menu.jsp';");
                                out.println("</script>");
                            }
                        }
                   
                    }
                        else{
                                response.setContentType("text/html");
                            try (PrintWriter out = response.getWriter()) {
                                out.println("<script type=\"text/javascript\">");
                                out.println("alert('No se encontro al cliente');");
                                out.println("location='menu.jsp';");
                                out.println("</script>");
                            }
                        }
                    
                }
                    
                    
        }
    }

