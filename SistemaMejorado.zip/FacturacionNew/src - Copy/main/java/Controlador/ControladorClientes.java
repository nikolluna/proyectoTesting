/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controlador;

import Modelo.Cliente;
import Modelo.ClientesDali;
import Modelo.Usuario;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author saman
 */
public class ControladorClientes extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String rucCliente = request.getParameter("rucCliente");
        String nombreCliente = request.getParameter("nombreCliente");
        String direccionCliente = request.getParameter("direccionCliente");
        
        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuario");

        if (rucCliente == null || !rucCliente.matches("\\d{11}") || rucCliente.equals("00000000000")) {
            enviarMensajeError(response, "El RUC debe contener 11 dígitos y sólo números.");
            response.sendRedirect("registroCliente.jsp");
        }
        else{
            if (nombreCliente == null || nombreCliente.length() < 4 || nombreCliente.length() > 40 || !nombreCliente.matches("[A-Za-z]+\\s[A-Za-z]+")) {
                enviarMensajeError(response, "El nombre tiene un máximo de 40 caracteres y contener al menos dos nombres.");
                response.sendRedirect("registroCliente.jsp");
            }
            else{
                if (direccionCliente == null || direccionCliente.length() < 4 || direccionCliente.length() > 40) {
                enviarMensajeError(response, "La dirección tiene un máximo de 40 caracteres.");
                response.sendRedirect("registroCliente.jsp");
                }
                else{
                    System.out.println("Llegué a registrar cliente");
                    Cliente cliente = new Cliente();
                    cliente.setRucCliente(rucCliente);
                    cliente.setNombreCliente(nombreCliente);
                    cliente.setDireccionCliente(direccionCliente);

                    ClientesDali clienteDali = new ClientesDali();
                    Cliente clientere = clienteDali.buscarClientePorRucYCorreo(cliente.getRucCliente(), usuario);
                    if(clientere==null){
                        int resultado = clienteDali.enviar(cliente, usuario);
                        if (resultado > 0) {
                            response.setContentType("text/html");
                                        try (PrintWriter out = response.getWriter()) {
                                            out.println("<script type=\"text/javascript\">");
                                            out.println("alert('Se registro al cliente');");
                                            out.println("location='menu.jsp';");
                                            out.println("</script>");
                                        }
                            response.sendRedirect("menu.jsp");
                        } 
                        else{
                            response.sendRedirect("error.jsp");
                        }
                    }
                    else{
                        response.setContentType("text/html");
                            try (PrintWriter out = response.getWriter()) {
                                out.println("<script type=\"text/javascript\">");
                                out.println("alert('El cliente ya está registrado.');");
                                out.println("location='menu.jsp';");
                                out.println("</script>");
                            }
                    }
                    }
                    
                }
            }
        }
    private void enviarMensajeError(HttpServletResponse response, String mensaje) throws IOException {
        response.setContentType("text/html");
        try (PrintWriter out = response.getWriter()) {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('" + mensaje + "');");
            out.println("location='registroCliente.jsp';");
            out.println("</script>");
        }
    }   
}

