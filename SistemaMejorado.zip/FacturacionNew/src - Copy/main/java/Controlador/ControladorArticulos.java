/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controlador;

import Modelo.Articulo;
import Modelo.ArticuloDali;
import Modelo.Usuario;
import Modelo.UsuarioDali;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;

/**
 *
 * @author saman
 */
public class ControladorArticulos extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                UsuarioDali val = new UsuarioDali();
                Double precioProducto=0.0;
		String precioProductostr = request.getParameter("productPrice");
                String nombreProducto = request.getParameter("productName");
                HttpSession session = request.getSession();
                
                Usuario usuario = (Usuario) session.getAttribute("usuario");
		if (precioProductostr != null && precioProductostr.matches("^\\d+(\\.\\d{1,2})?$")) {
                    precioProducto = Double.parseDouble(precioProductostr);
                    if(nombreProducto == null || nombreProducto.length() < 3 || nombreProducto.length() > 100 || !nombreProducto.matches("[A-Za-z ]+")){
                        enviarMensajeError(response, "El nombre no puede ser nulo ni repetido");
                    }
                    else{
                        System.out.println("Lllegueeee");
                        Articulo producto = new Articulo();
                        System.out.println("des: "+nombreProducto);
                        System.out.println("pre: "+precioProducto);

                        producto.setDescripcion(nombreProducto);
                        producto.setPrecio_u(precioProducto);
                        System.out.println("usuario: "+usuario.getCorreo());
                        ArticuloDali productoDali = new ArticuloDali();
                        Articulo productoa = productoDali.buscarPorDescripcionYCorrero(producto.getDescripcion(), usuario);

                        if((productoa==null)){
                            int resultado = productoDali.enviar(producto,usuario);
                            List<Articulo> listaArticulos2 = productoDali.listarArticulos(usuario);
                            for (Articulo articulo : listaArticulos2) {
                                System.out.println("ID: " + articulo.getId_articulo());
                                System.out.println("Descripción: " + articulo.getDescripcion());
                                System.out.println("Precio: " + articulo.getPrecio_u());
                                System.out.println("-----------------------");
                            }

                            if (resultado > 0) {
                                List<Articulo> listaArticulos = val.listarArticulos(usuario);
                                        List<Double> precios = new ArrayList<>();
                                        List<String> descripciones = new ArrayList<>();
                                for (Articulo articulo : listaArticulos) {
                                            System.out.println("ARTICULO: "+articulo.getDescripcion());
                                            descripciones.add(articulo.getDescripcion());
                                            precios.add(articulo.getPrecio_u());
                                }
                                session.setAttribute("descripciones", descripciones);
                                session.setAttribute("precios", precios);
                                request.setAttribute("articulo", listaArticulos);
                                response.setContentType("text/html");
                                            try (PrintWriter out = response.getWriter()) {
                                                out.println("<script type=\"text/javascript\">");
                                                out.println("alert('Se registro el producto');");
                                                out.println("location='menu.jsp';");
                                                out.println("</script>");
                                            }
                                response.sendRedirect("menu.jsp");
                            } else {
                                // Error al registrar el producto
                                response.setContentType("text/html");
                                try (PrintWriter out = response.getWriter()) {
                                    out.println("<script type=\"text/javascript\">");
                                    out.println("alert('El producto ya está registrado.');");
                                    out.println("location='menu.jsp';");
                                    out.println("</script>");
                                }
                            }
                        }
                        else{
                            response.setContentType("text/html");
                                try (PrintWriter out = response.getWriter()) {
                                    out.println("<script type=\"text/javascript\">");
                                    out.println("alert('El producto ya está registrado.');");
                                    out.println("location='menu.jsp';");
                                    out.println("</script>");
                                }
                        }

                    }
                } else {
                    enviarMensajeError(response, "El precio del producto debe tener un formato correcto con hasta dos decimales y solo números.");
                    
                }
	    
	    
        
    }
    private void enviarMensajeError(HttpServletResponse response, String mensaje) throws IOException {
        response.setContentType("text/html");
        try (PrintWriter out = response.getWriter()) {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('" + mensaje + "');");
            out.println("location='registroProducto.jsp';");
            out.println("</script>");
        }
    }
}

