/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author saman
 */
public class ClientesDali {
    Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    int res = 0;

    public void abrirConexion() throws SQLException {
        con = cn.getConexion();
    }

    public void cerrarConexion() {
        try {
            if (con != null) {
                con.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public int enviar(Cliente cliente, Usuario us) {
        int resultado = 0;
        String sql = "INSERT INTO cliente (ruc_cliente, nombre_cliente, direccion_cliente, correo_user) VALUES (?, ?, ?, ?)";
        try {
            abrirConexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, cliente.getRucCliente());
            ps.setString(2, cliente.getNombreCliente());
            ps.setString(3, cliente.getDireccionCliente());
            ps.setString(4, us.getCorreo());
            resultado = ps.executeUpdate();
            System.out.println("RETORNO 1");
            return 1;
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return resultado;
    }
    
        public Cliente buscarClientePorRucYCorreo(String rucCliente, Usuario us) {
        Cliente cliente = null;
        String sql = "SELECT * FROM cliente WHERE ruc_cliente = ? AND correo_user = ?";
        try {
            abrirConexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, rucCliente);
            ps.setString(2, us.getCorreo());
            rs = ps.executeQuery();
            if (rs.next()) {
                cliente = new Cliente();
                cliente.setRucCliente(rs.getString("ruc_cliente"));
                cliente.setNombreCliente(rs.getString("nombre_cliente"));
                cliente.setDireccionCliente(rs.getString("direccion_cliente"));
            }
            return cliente;
        } catch (SQLException e) {
            e.printStackTrace();
        } 
        return cliente;
    }


}
